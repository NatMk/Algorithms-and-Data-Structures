/******************************************************
* Driver to handle operations in 2320 Lab 3, Spr 2017 *
* it processes the tree based on user command         *
*******************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "RB.h"

int main()
{
   int op,key,rank;
   STinit();  /* Initialize red-black tree */
   verifyRBproperties();

   scanf("%d",&op);

   while (op)
  {
       switch (op)
       {
           case 0:
           
           exit(0); //exits program if user enters 0

    	   case 1:

      	   scanf("%d",&key);
           printf("1 %d\n",key);
           STinsert(key);
           break;

           case 2:

           scanf("%d",&key);
           printf("2 %d\n",key);//delets a key value using STdelete(key);
           break;
  
           case 3:

           scanf("%d",&key);
           printf("3 %d\n",key);
           rank = STinvSelect(key);

           if(rank == (-1))
              printf("Key %d is not in tree\n",key);
           else
             printf("Key %d has rank %d\n",key,rank);
           break;

           case 4:

           scanf("%d",&rank);
           printf("4 %d\n",rank);

           if (rank<1 /*|| rank>getLive()*/)
              printf("rank %d range error\n",rank);
           else
              printf("rank %d has key %d\n",rank,key(STselect(rank)));
           break;

           case 5:
  
           printf("5\n");
           //"printing status" printf("Live %d Dead %d Recycled %d\n",getLive(),getDead(),getRecycled());
           break;

           case 6:
  
           printf("6\n");

           /* checking for dead key using if (getDead()*)removeDead(); *///function call to clean up the dead keys
           break;

           case 7:
  
           printf("7\n");
           STprintTree();
           break;

           case 8:

           printf("8\n");
           /* checks for black height if (verifyRBproperties()) *///function call
	      printf("clean\n"); 
           if (1)
               printf("clean\n");
           else
              printf("corrupt\n");
           break;

           default:

           printf("Bad operation %d\n",op);
    }

     scanf("%d",&op);
  }
}
